##3.设置 tableView 的每组的间距

![显示图片](../images/zhuyi5.jpg)

设置 tableView 的每组的间距

![显示图片](../images/zhuyi6.jpg)
