
##2.自定义按钮, 文字显示不完全
![显示图片](../images/zhuyi3.jpg)

问题: 自定义按钮, 文字显示不完全

处理: 调用 sizeToFit 让系统重新计算 titleLabel 的大小

![显示图片](../images/zhuyi4.jpg)
