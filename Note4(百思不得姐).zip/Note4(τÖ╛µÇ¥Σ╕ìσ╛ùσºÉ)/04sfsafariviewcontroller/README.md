##4.SFSafariViewController 的使用

使用 presentViewController: 展示, 这样, 就不用设置代理, 返回等按钮的操作, 系统已经帮我们处理好了

![显示图片](../images/zhuyi7.jpg)
