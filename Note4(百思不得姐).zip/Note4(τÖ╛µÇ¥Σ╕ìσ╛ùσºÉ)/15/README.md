####缩放 scrollView 上的 imageView

- 1.设置 scrllView 的代理，并设置 scrollView 的缩放比例
*![显示图片](../images/15-1.jpg)*

- 2.遵守协议UIScrollViewDelegate
- 3.实现 `viewForZoomingInScrollView` 代理方法
*![显示图片](../images/15-2.jpg)*
