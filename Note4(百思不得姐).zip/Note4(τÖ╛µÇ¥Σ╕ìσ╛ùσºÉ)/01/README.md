#注意点

##1.图片的填充方式

![显示图片](../images/zhuyi1.jpg)

图片的填充方式改成:

![显示图片](../images/zhuyi2.jpg)








